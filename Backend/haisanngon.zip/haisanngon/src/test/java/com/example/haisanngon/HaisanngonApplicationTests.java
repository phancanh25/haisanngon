package com.example.haisanngon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaisanngonApplicationTests {

	@Test
	void contextLoads() {
	}

}
